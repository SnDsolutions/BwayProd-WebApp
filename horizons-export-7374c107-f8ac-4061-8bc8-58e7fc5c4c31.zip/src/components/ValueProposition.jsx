
import React from 'react';
import { motion } from 'framer-motion';
import { Star, Film, Sprout } from 'lucide-react';

const ValueProposition = () => {
  return (
    <section className="py-20 bg-grafito relative overflow-hidden">
      {/* The entire ValueProposition section content has been removed as per user request */}
    </section>
  );
};

export default ValueProposition;
