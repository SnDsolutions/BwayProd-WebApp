import React from 'react';
import Plans from '@/components/Plans';

const PlansPage = () => {
  return (
    <div className="pt-24">
      <Plans />
    </div>
  );
};

export default PlansPage;